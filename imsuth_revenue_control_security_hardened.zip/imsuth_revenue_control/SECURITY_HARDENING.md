# Security hardening and production-readiness plan

This package is a payment integration starter, not a production-certified clinical or revenue system. The code change in this revision removes patient identifier, department, and service details from Monnify payment metadata and uses a generic payment description. Complete every control below before production.

## Application access control — REQUIRED BEFORE LIVE USE

The current application still authenticates against one environment-configured username/password. That is not individual-account or role-based access control. Replace it before production with:
- `users` table: unique username, password hash (Argon2id or scrypt; never plaintext), role, enabled flag, password-change timestamp, created/updated timestamps, and optional MFA enrollment.
- Roles and server-side authorization: `admin` (user administration/configuration), `finance` (view/reconcile/export payments), `cashier` (initiate payments and view permitted transactions), `auditor` (read-only reports/audit logs). Deny by default and check permissions in every API route, not just in the UI.
- Admin-only user create/disable/role-change/password-reset endpoints. No public self-registration. Require a separate named account for each staff member; immediately disable leavers.
- Password policy: minimum 15 characters for password-only login (or at least 8 with MFA), block common/compromised passwords, allow password managers and paste, no arbitrary periodic changes absent compromise. Hash using a maintained password-hashing library with a per-password salt.
- MFA for administrators and privileged roles; re-authentication for role changes, exports, and other high-risk actions.
- Login throttling and account-based progressive delay using a shared store (database or Redis) so it works across all uWSGI workers. Use generic login errors, log lockouts, and alert on repeated failures. Do not rely on in-process counters.
- Rotate session ID after login; use Secure, HttpOnly, SameSite cookies, short idle and absolute expiry, and revoke sessions on account disable/password reset. Keep CSRF protection on state-changing routes.
- Add automated authorization tests for every route and role. Until this work is completed, do not expose the app to production data.

## Database least privilege

Use a dedicated runtime database user. Do not run the web app as MySQL root or with schema-management privileges. Apply schema migrations using a separate deployment identity, then grant only required DML permissions to the runtime user. Restrict database network access to the application host/private network and require TLS for remote DB connections.

Example grant template (replace database/user/host, review privileges against the deployed schema, and run as a DBA):

```sql
CREATE USER 'imsuth_runtime'@'APP_PRIVATE_HOST' IDENTIFIED BY 'GENERATE_A_UNIQUE_SECRET';
GRANT SELECT, INSERT, UPDATE, DELETE ON imsuth_revenue.payments TO 'imsuth_runtime'@'APP_PRIVATE_HOST';
GRANT SELECT, INSERT, UPDATE ON imsuth_revenue.webhook_events TO 'imsuth_runtime'@'APP_PRIVATE_HOST';
GRANT INSERT, SELECT ON imsuth_revenue.audit_log TO 'imsuth_runtime'@'APP_PRIVATE_HOST';
-- Grant only the minimum additional privileges required by the implemented users/session tables.
-- Do NOT grant CREATE, ALTER, DROP, FILE, PROCESS, SUPER, or GRANT OPTION to runtime.
```

The exact grants must be tested against the final schema. `AUTO_INIT_DB=true` is incompatible with a least-privilege runtime identity because the app creates tables. Set `AUTO_INIT_DB=false` in production and apply reviewed migrations separately.

## Secrets

- Use a managed secret store or deployment platform secret injection for `APP_SECRET_KEY`, Monnify API/secret keys, and database password. Do not put production secrets in Git, images, logs, tickets, or backups without encryption.
- Restrict `.env` permissions to the service account (`chmod 600 .env`) when a secret manager is unavailable; ensure it is excluded from source control and deployments.
- Rotate exposed or suspected secrets, document ownership and rotation cadence, and separate sandbox and production credentials.
- Use unique high-entropy secrets. Never use example values in production. The app now refuses a missing/placeholder Flask secret when `APP_ENV=production`; set `APP_ENV=production` in production.

## Monitoring, alerting, and audit

- Ship application, Nginx, OS, database, and authentication logs to a restricted, centralized logging system.
- Alert on repeated login failures/lockouts, admin or role changes, unusual exports, invalid webhook signatures, repeated webhook processing failures, DB connection errors, backup failures, disk exhaustion, and service downtime.
- Audit events should include actor ID, action, timestamp, outcome, and correlation/reference IDs. Do not log passwords, session/CSRF tokens, API keys, full payment payloads, or clinical details.
- Review audit logs at least monthly and after suspected incidents. Keep logs tamper-resistant and define retention/access rules.
- The existing `audit_log` table is a useful starting point but is not tamper-proof, and current webhook storage persists full payloads. Minimize and redact webhook payloads, restrict access, and define short retention after operational/legal review.

## Off-server backups and restore tests

- Use encrypted automated backups stored in a separate account/provider or immutable object storage; application/database credentials must not be able to delete all backup copies.
- Back up database plus required configuration/migration artifacts. Do not casually back up `.env` plaintext; if configuration is backed up, encrypt it with separately managed keys.
- Define RPO/RTO with hospital leadership, retention, encryption, access controls, and alerting for missed backups.
- Perform a documented restore into an isolated environment at least quarterly and after material schema changes. Verify row counts, reconciliation totals, indexes, application startup, access controls, and payment status integrity. Record evidence and remediation actions.

The included `deployment/backup_mysql.sh` and `deployment/test_restore_mysql.sh` are operational templates. Configure credentials through a protected MySQL option file or secret manager; do not pass passwords on command lines. Test them in a non-production environment before scheduling.

## Data protection and independent security testing

- Complete a data inventory and privacy impact assessment with the hospital's data-protection lead. Establish purpose, lawful basis, minimization, retention/deletion, data-subject handling, processor contracts, breach response, and cross-border transfer review as applicable.
- Avoid storing clinical diagnosis/procedure details in payment metadata. This revision sends only a generic payment description plus hospital/payment reference to Monnify. Review whether patient name/email are needed by the provider and minimize them where provider requirements allow.
- Before launch, commission independent penetration testing and code/configuration review. Fix critical/high findings and retest. Repeat after major changes and periodically.
- Enforce HTTPS, secure headers, patched dependencies/OS, least-privilege service account, firewall restrictions, and incident-response exercises.
- Test Monnify webhook signature validation and transaction verification against current provider documentation before live traffic.

## Current status and limitations

Implemented in this revision:
- Reduced Monnify payment description/metadata to generic hospital payment and local payment reference.
- Flask session secret no longer silently uses a fixed placeholder in production mode; secure session cookies default on.

Not implemented by this revision:
- Individual accounts, RBAC enforcement, database-backed login throttling, MFA, shared-session revocation, centralized alerting, and fully automated backup scheduling.
These require application/deployment changes and validation. Do not treat this archive as production-ready until they are implemented and independently tested.
