#!/usr/bin/env bash
# Template: schedule with systemd timer/cron on a secured host.
# Configure MYSQL_CNF to a root-readable (0600) option file, and BACKUP_DEST to
# an encrypted off-server destination (e.g. mounted object-storage gateway).
set -euo pipefail
: "${MYSQL_CNF:?Set MYSQL_CNF to a protected MySQL option file}"
: "${MYSQL_DATABASE:?Set MYSQL_DATABASE}"
: "${BACKUP_DEST:?Set BACKUP_DEST to encrypted off-server storage}"
umask 077
command -v mysqldump >/dev/null
command -v gzip >/dev/null
mkdir -p "$BACKUP_DEST"
stamp="$(date -u +%Y%m%dT%H%M%SZ)"
tmp="$(mktemp)"
trap 'rm -f "$tmp"' EXIT
mysqldump --defaults-extra-file="$MYSQL_CNF" \
  --single-transaction --routines --triggers --hex-blob \
  --databases "$MYSQL_DATABASE" | gzip -c > "$tmp"
test -s "$tmp"
dest="$BACKUP_DEST/${MYSQL_DATABASE}-${stamp}.sql.gz"
install -m 600 "$tmp" "$dest"
sha256sum "$dest" > "${dest}.sha256"
echo "Backup created: $dest"
# Configure destination-side encryption, immutable retention, and failure alerts.
# Do not count a local-only backup as off-server protection.
