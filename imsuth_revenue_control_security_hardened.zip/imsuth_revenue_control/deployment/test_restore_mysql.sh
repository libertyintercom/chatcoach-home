#!/usr/bin/env bash
# Destructive to the target database. Run ONLY against an isolated restore-test DB.
set -euo pipefail
: "${MYSQL_CNF:?Set MYSQL_CNF to a protected MySQL option file}"
: "${BACKUP_FILE:?Set BACKUP_FILE to a backup .sql.gz file}"
: "${RESTORE_DATABASE:?Set RESTORE_DATABASE to an isolated empty test database}"
if [[ "${CONFIRM_ISOLATED_RESTORE:-}" != "yes" ]]; then
  echo "Set CONFIRM_ISOLATED_RESTORE=yes only after verifying this is NOT production." >&2
  exit 2
fi
test -s "$BACKUP_FILE"
if [[ -f "${BACKUP_FILE}.sha256" ]]; then
  sha256sum -c "${BACKUP_FILE}.sha256"
fi
gzip -t "$BACKUP_FILE"
# The backup generated above contains CREATE DATABASE/USE statements. For a true
# isolated test, restore into a disposable MySQL instance or use a reviewed
# remapped dump; never point this script at production credentials.
echo "Preflight passed. Restore manually into a disposable MySQL instance, then run reconciliation checks."
echo "This script intentionally does not execute a destructive import automatically."
