import os
import json
import hmac
import hashlib
import secrets
from decimal import Decimal, InvalidOperation
from functools import wraps
from datetime import datetime, timezone
from urllib.parse import urlencode

import requests
import mysql.connector
from mysql.connector import pooling
from flask import Flask, request, jsonify, render_template, session, redirect, url_for, make_response
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
_app_secret = os.getenv("APP_SECRET_KEY", "").strip()
if not _app_secret or _app_secret.startswith("CHANGE-ME"):
    if os.getenv("APP_ENV", "development").lower() == "production":
        raise RuntimeError("APP_SECRET_KEY must be supplied from a secret manager in production")
    _app_secret = secrets.token_urlsafe(48)
app.secret_key = _app_secret
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "true").lower() == "true",
    PERMANENT_SESSION_LIFETIME=__import__("datetime").timedelta(hours=8),
)

ENVIRONMENT = os.getenv("MONNIFY_ENV", "sandbox").lower()
BASE_URL = "https://api.monnify.com" if ENVIRONMENT == "live" else "https://sandbox.monnify.com"
MONNIFY_API_KEY = os.getenv("MONNIFY_API_KEY", "").strip()
MONNIFY_SECRET_KEY = os.getenv("MONNIFY_SECRET_KEY", "").strip()
MONNIFY_CONTRACT_CODE = os.getenv("MONNIFY_CONTRACT_CODE", "").strip()
APP_BASE_URL = os.getenv("APP_BASE_URL", "http://127.0.0.1:5000").rstrip("/")
APP_USERNAME = os.getenv("APP_USERNAME", "admin")
APP_PASSWORD = os.getenv("APP_PASSWORD", "CHANGE-ME-now")
HOSPITAL_NAME = os.getenv("HOSPITAL_NAME", "IMSUTH Revenue Control")
CURRENCY = "NGN"

pool = None

def get_pool():
    global pool
    if pool is None:
        pool = pooling.MySQLConnectionPool(
            pool_name="imsuth_pool",
            pool_size=int(os.getenv("MYSQL_POOL_SIZE", "5")),
            host=os.getenv("MYSQL_HOST", "127.0.0.1"),
            port=int(os.getenv("MYSQL_PORT", "3306")),
            user=os.getenv("MYSQL_USER", "imsuth_app"),
            password=os.getenv("MYSQL_PASSWORD", ""),
            database=os.getenv("MYSQL_DATABASE", "imsuth_revenue"),
            autocommit=False,
            connection_timeout=8,
        )
    return pool

def db_connection():
    return get_pool().get_connection()

def init_db():
    """Create the app's tables if they do not already exist."""
    statements = [
        """
        CREATE TABLE IF NOT EXISTS payments (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
          payment_reference VARCHAR(120) NOT NULL,
          transaction_reference VARCHAR(120) NULL,
          patient_name VARCHAR(180) NULL,
          patient_identifier VARCHAR(100) NULL,
          customer_email VARCHAR(254) NULL,
          department VARCHAR(120) NULL,
          service_name VARCHAR(180) NULL,
          amount_expected DECIMAL(14,2) NULL,
          amount_paid DECIMAL(14,2) NOT NULL DEFAULT 0.00,
          currency CHAR(3) NOT NULL DEFAULT 'NGN',
          payment_method VARCHAR(60) NULL,
          payment_status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
          paid_on VARCHAR(80) NULL,
          monnify_environment VARCHAR(12) NOT NULL DEFAULT 'sandbox',
          checkout_url TEXT NULL,
          raw_event JSON NULL,
          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
          UNIQUE KEY uq_payment_reference (payment_reference),
          UNIQUE KEY uq_transaction_reference (transaction_reference),
          KEY ix_payment_status (payment_status),
          KEY ix_created_at (created_at),
          KEY ix_department (department)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS webhook_events (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
          event_key VARCHAR(190) NOT NULL,
          event_type VARCHAR(100) NULL,
          payment_reference VARCHAR(120) NULL,
          received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          processed_at TIMESTAMP NULL,
          processing_status VARCHAR(40) NOT NULL DEFAULT 'RECEIVED',
          error_message VARCHAR(500) NULL,
          payload JSON NOT NULL,
          UNIQUE KEY uq_webhook_event_key (event_key),
          KEY ix_webhook_received (received_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """,
        """
        CREATE TABLE IF NOT EXISTS audit_log (
          id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
          actor VARCHAR(100) NOT NULL,
          action VARCHAR(100) NOT NULL,
          detail JSON NULL,
          created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
          KEY ix_audit_created (created_at)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
        """
    ]
    conn = db_connection()
    try:
        cur = conn.cursor()
        for statement in statements:
            cur.execute(statement)
        conn.commit()
        cur.close()
    finally:
        conn.close()

def log_audit(actor, action, detail=None):
    conn = db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO audit_log (actor, action, detail) VALUES (%s, %s, %s)",
            (actor, action, json.dumps(detail or {}, default=str)),
        )
        conn.commit()
        cur.close()
    finally:
        conn.close()

def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("authenticated"):
            return jsonify({"error": "Authentication required"}), 401
        return fn(*args, **kwargs)
    return wrapped

@app.before_request
def csrf_guard():
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        if request.path == "/webhooks/monnify" or request.path == "/api/login":
            return None
        if session.get("authenticated"):
            expected = session.get("csrf_token", "")
            supplied = request.headers.get("X-CSRF-Token", "")
            if not expected or not hmac.compare_digest(expected, supplied):
                return jsonify({"error": "Invalid CSRF token"}), 403

@app.get("/")
def index():
    if not session.get("authenticated"):
        return render_template("login.html", hospital_name=HOSPITAL_NAME)
    return render_template("dashboard.html", hospital_name=HOSPITAL_NAME)

@app.get("/health")
def health():
    return jsonify({"ok": True, "service": "imsuth-revenue-control"})

@app.post("/api/login")
def api_login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", ""))
    password = str(data.get("password", ""))
    valid_user = hmac.compare_digest(username, APP_USERNAME)
    valid_password = hmac.compare_digest(password, APP_PASSWORD)
    if not valid_user or not valid_password:
        return jsonify({"error": "Invalid username or password"}), 401
    session.clear()
    session["authenticated"] = True
    session["username"] = username
    session["csrf_token"] = secrets.token_urlsafe(32)
    session.permanent = True
    log_audit(username, "LOGIN", {"source": request.remote_addr})
    return jsonify({"ok": True, "csrf_token": session["csrf_token"]})

@app.post("/api/logout")
@login_required
def api_logout():
    username = session.get("username", "unknown")
    log_audit(username, "LOGOUT")
    session.clear()
    return jsonify({"ok": True})

@app.get("/api/session")
@login_required
def api_session():
    return jsonify({
        "username": session.get("username"),
        "csrf_token": session.get("csrf_token"),
        "hospital_name": HOSPITAL_NAME,
        "environment": ENVIRONMENT,
    })

def monnify_headers():
    if not MONNIFY_API_KEY or not MONNIFY_SECRET_KEY:
        raise RuntimeError("Set MONNIFY_API_KEY and MONNIFY_SECRET_KEY in .env")
    credentials = (MONNIFY_API_KEY + ":" + MONNIFY_SECRET_KEY).encode("utf-8")
    import base64
    encoded = base64.b64encode(credentials).decode("ascii")
    response = requests.post(
        BASE_URL + "/api/v1/auth/login",
        headers={"Authorization": "Basic " + encoded, "Content-Type": "application/json"},
        timeout=(3.05, 10),
    )
    response.raise_for_status()
    body = response.json()
    if not body.get("requestSuccessful") or not body.get("responseBody", {}).get("accessToken"):
        raise RuntimeError("Monnify authentication failed")
    return {"Authorization": "Bearer " + body["responseBody"]["accessToken"],
            "Content-Type": "application/json"}

def verify_monnify_payment(payment_reference):
    headers = monnify_headers()
    response = requests.get(
        BASE_URL + "/api/v2/merchant/transactions/query",
        params={"paymentReference": payment_reference},
        headers=headers,
        timeout=(3.05, 10),
    )
    response.raise_for_status()
    body = response.json()
    if not body.get("requestSuccessful"):
        raise RuntimeError("Monnify transaction verification was unsuccessful")
    return body.get("responseBody") or {}

@app.post("/api/payments/initiate")
@login_required
def initiate_payment():
    data = request.get_json(silent=True) or {}
    try:
        amount = Decimal(str(data.get("amount", "")).replace(",", "")).quantize(Decimal("0.01"))
    except (InvalidOperation, ValueError):
        return jsonify({"error": "Enter a valid amount"}), 400
    if amount <= 0 or amount > Decimal("100000000"):
        return jsonify({"error": "Amount must be greater than zero and within the allowed limit"}), 400
    if not MONNIFY_API_KEY or not MONNIFY_SECRET_KEY or not MONNIFY_CONTRACT_CODE:
        return jsonify({"error": "Configure Monnify API key, secret key and contract code in .env first"}), 503

    payment_reference = "IMSUTH-" + datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S") + "-" + secrets.token_hex(5).upper()
    patient_name = str(data.get("patient_name", "")).strip()[:180]
    patient_identifier = str(data.get("patient_identifier", "")).strip()[:100]
    email = str(data.get("email", "")).strip()[:254]
    department = str(data.get("department", "")).strip()[:120]
    service_name = str(data.get("service_name", "")).strip()[:180]
    if not patient_name or not service_name or not department:
        return jsonify({"error": "Patient name, department and service are required"}), 400
    if email and ("@" not in email or len(email) > 254):
        return jsonify({"error": "Enter a valid email address or leave it blank"}), 400

    conn = db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO payments
               (payment_reference, patient_name, patient_identifier, customer_email,
                department, service_name, amount_expected, amount_paid, currency,
                payment_status, monnify_environment)
               VALUES (%s,%s,%s,%s,%s,%s,%s,0.00,'NGN','PENDING',%s)""",
            (payment_reference, patient_name, patient_identifier, email or None,
             department, service_name, str(amount), ENVIRONMENT),
        )
        conn.commit()
        cur.close()
    finally:
        conn.close()

    payload = {
        "amount": float(amount),
        "customerName": patient_name,
        "customerEmail": email or (payment_reference.lower() + "@payments.imsuth.local"),
        "paymentReference": payment_reference,
        "paymentDescription": "IMSUTH hospital payment",
        "currencyCode": "NGN",
        "contractCode": MONNIFY_CONTRACT_CODE,
        "redirectUrl": APP_BASE_URL + "/payment-return",
        "paymentMethods": ["CARD", "ACCOUNT_TRANSFER", "USSD"],
        # Do not send patient identifiers, clinical service names, or department
        # details to payment-provider metadata. Keep operational mapping locally.
        "metaData": {
            "hospital": HOSPITAL_NAME,
            "paymentReference": payment_reference,
        },
    }
    try:
        response = requests.post(
            BASE_URL + "/api/v1/merchant/transactions/init-transaction",
            headers=monnify_headers(),
            json=payload,
            timeout=(3.05, 15),
        )
        response.raise_for_status()
        result = response.json()
        if not result.get("requestSuccessful"):
            raise RuntimeError(result.get("responseMessage", "Monnify rejected payment initialization"))
        rb = result.get("responseBody") or {}
        checkout_url = rb.get("checkoutUrl")
        if not checkout_url:
            raise RuntimeError("Monnify did not return a checkout URL")
        conn = db_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "UPDATE payments SET transaction_reference=%s, checkout_url=%s WHERE payment_reference=%s",
                (rb.get("transactionReference"), checkout_url, payment_reference),
            )
            conn.commit()
            cur.close()
        finally:
            conn.close()
        log_audit(session.get("username", "unknown"), "PAYMENT_INITIATED",
                  {"payment_reference": payment_reference, "amount": str(amount)})
        return jsonify({"ok": True, "payment_reference": payment_reference, "checkout_url": checkout_url})
    except Exception as exc:
        # Keep the local row as PENDING for troubleshooting; never mark it as paid.
        app.logger.exception("Monnify payment initialization failed")
        return jsonify({"error": "Could not initialize payment with Monnify. Check server logs and Monnify configuration."}), 502

@app.get("/payment-return")
def payment_return():
    # The return URL is only a user-facing status page. It does not confirm payment.
    return render_template("return.html", hospital_name=HOSPITAL_NAME)

def validate_webhook_signature(raw_body):
    signature = request.headers.get("monnify-signature", "")
    if ENVIRONMENT != "live" and not signature:
        return True  # Monnify documents that sandbox webhooks may omit this header.
    if not signature or not MONNIFY_SECRET_KEY:
        return False
    expected = hmac.new(
        MONNIFY_SECRET_KEY.encode("utf-8"),
        raw_body,
        hashlib.sha512,
    ).hexdigest()
    return hmac.compare_digest(expected.lower(), signature.strip().lower())

@app.post("/webhooks/monnify")
def monnify_webhook():
    raw = request.get_data(cache=True)
    if not validate_webhook_signature(raw):
        app.logger.warning("Rejected Monnify webhook with invalid signature")
        return jsonify({"error": "Invalid signature"}), 401
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return jsonify({"error": "Invalid JSON"}), 400

    event_type = str(payload.get("eventType", "UNKNOWN"))
    event_data = payload.get("eventData") or {}
    payment_reference = str(event_data.get("paymentReference", "")).strip()
    transaction_reference = str(event_data.get("transactionReference", "")).strip()
    event_key = transaction_reference or payment_reference or hashlib.sha256(raw).hexdigest()

    # Persist each webhook idempotently. Duplicate delivery gets a 200 response.
    conn = db_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(
            """INSERT IGNORE INTO webhook_events
               (event_key,event_type,payment_reference,payload,processing_status)
               VALUES (%s,%s,%s,%s,'RECEIVED')""",
            (event_key, event_type, payment_reference or None, json.dumps(payload, default=str)),
        )
        inserted = cur.rowcount == 1
        conn.commit()
        cur.close()
    finally:
        conn.close()
    if not inserted:
        return jsonify({"ok": True, "duplicate": True}), 200

    try:
        if event_type != "SUCCESSFUL_TRANSACTION" or str(event_data.get("paymentStatus", "")).upper() != "PAID":
            conn = db_connection()
            try:
                cur = conn.cursor()
                cur.execute(
                    "UPDATE webhook_events SET processing_status='IGNORED', processed_at=NOW() WHERE event_key=%s",
                    (event_key,),
                )
                conn.commit()
                cur.close()
            finally:
                conn.close()
            return jsonify({"ok": True, "ignored": True}), 200

        if not payment_reference:
            raise RuntimeError("Webhook has no paymentReference")

        # Confirm with Monnify's server-side transaction query before marking paid.
        verified = verify_monnify_payment(payment_reference)
        status = str(verified.get("paymentStatus", "")).upper()
        if status != "PAID":
            raise RuntimeError("Monnify transaction query did not confirm PAID status")

        verified_amount = Decimal(str(verified.get("amountPaid", event_data.get("amountPaid", "0")))).quantize(Decimal("0.01"))
        currency = str(verified.get("currencyCode") or verified.get("currency") or event_data.get("currency") or "NGN").upper()
        if verified_amount <= 0 or currency != "NGN":
            raise RuntimeError("Verified amount or currency is invalid")

        conn = db_connection()
        try:
            cur = conn.cursor(dictionary=True)
            cur.execute("SELECT * FROM payments WHERE payment_reference=%s FOR UPDATE", (payment_reference,))
            existing = cur.fetchone()
            if existing and existing.get("amount_expected") is not None:
                expected_amount = Decimal(str(existing["amount_expected"])).quantize(Decimal("0.01"))
                if expected_amount != verified_amount:
                    cur.execute(
                        "UPDATE payments SET payment_status='REVIEW', amount_paid=%s, raw_event=%s WHERE payment_reference=%s",
                        (str(verified_amount), json.dumps(payload, default=str), payment_reference),
                    )
                    cur.execute(
                        "UPDATE webhook_events SET processing_status='REVIEW', error_message='Amount differs from expected amount', processed_at=NOW() WHERE event_key=%s",
                        (event_key,),
                    )
                    conn.commit()
                    cur.close()
                    return jsonify({"ok": True, "review_required": True}), 200

            customer = verified.get("customer") or event_data.get("customer") or {}
            method = verified.get("paymentMethod") or event_data.get("paymentMethod") or "UNKNOWN"
            paid_on = str(verified.get("paidOn") or event_data.get("paidOn") or "")
            patient_name = (existing or {}).get("patient_name") or customer.get("name")
            customer_email = (existing or {}).get("customer_email") or customer.get("email")
            department = (existing or {}).get("department")
            service_name = (existing or {}).get("service_name")
            patient_identifier = (existing or {}).get("patient_identifier")
            expected = (existing or {}).get("amount_expected")

            if existing:
                cur.execute(
                    """UPDATE payments SET transaction_reference=%s, patient_name=%s,
                       customer_email=%s, amount_paid=%s, currency=%s, payment_method=%s,
                       payment_status='PAID', paid_on=%s, raw_event=%s
                       WHERE payment_reference=%s""",
                    (verified.get("transactionReference") or transaction_reference,
                     patient_name, customer_email, str(verified_amount), currency,
                     method, paid_on, json.dumps(payload, default=str), payment_reference),
                )
            else:
                # Also record verified Monnify payments created outside this app.
                cur.execute(
                    """INSERT INTO payments
                       (payment_reference,transaction_reference,patient_name,customer_email,
                        amount_expected,amount_paid,currency,payment_method,payment_status,
                        paid_on,monnify_environment,raw_event)
                       VALUES (%s,%s,%s,%s,NULL,%s,%s,%s,'PAID',%s,%s,%s)""",
                    (payment_reference, verified.get("transactionReference") or transaction_reference,
                     patient_name, customer_email, str(verified_amount), currency, method,
                     paid_on, ENVIRONMENT, json.dumps(payload, default=str)),
                )
            cur.execute(
                "UPDATE webhook_events SET processing_status='PROCESSED', processed_at=NOW() WHERE event_key=%s",
                (event_key,),
            )
            conn.commit()
            cur.close()
        finally:
            conn.close()
        return jsonify({"ok": True}), 200
    except Exception as exc:
        app.logger.exception("Webhook processing failed")
        conn = db_connection()
        try:
            cur = conn.cursor()
            cur.execute(
                "UPDATE webhook_events SET processing_status='ERROR', error_message=%s WHERE event_key=%s",
                (str(exc)[:480], event_key),
            )
            conn.commit()
            cur.close()
        finally:
            conn.close()
        # Non-200 prompts provider retries; duplicate event storage means manual/retry recovery is needed.
        return jsonify({"error": "Webhook could not be fully processed; check server logs"}), 500

@app.get("/api/dashboard/summary")
@login_required
def dashboard_summary():
    conn = db_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT
              COALESCE(SUM(CASE WHEN payment_status='PAID' AND DATE(updated_at)=CURDATE() THEN amount_paid ELSE 0 END),0) AS today_revenue,
              COALESCE(SUM(CASE WHEN payment_status='PAID' THEN amount_paid ELSE 0 END),0) AS total_paid,
              SUM(CASE WHEN payment_status='PAID' THEN 1 ELSE 0 END) AS successful_count,
              SUM(CASE WHEN payment_status='PENDING' THEN 1 ELSE 0 END) AS pending_count,
              SUM(CASE WHEN payment_status='REVIEW' THEN 1 ELSE 0 END) AS review_count
            FROM payments
        """)
        row = cur.fetchone() or {}
        cur.close()
        return jsonify({k: str(v or 0) for k, v in row.items()})
    finally:
        conn.close()

@app.get("/api/payments")
@login_required
def list_payments():
    limit = min(max(int(request.args.get("limit", "100")), 1), 500)
    search = request.args.get("q", "").strip()[:120]
    status = request.args.get("status", "").strip().upper()[:40]
    conn = db_connection()
    try:
        cur = conn.cursor(dictionary=True)
        sql = """SELECT id,payment_reference,transaction_reference,patient_name,patient_identifier,
                 customer_email,department,service_name,amount_expected,amount_paid,currency,
                 payment_method,payment_status,paid_on,created_at,updated_at
                 FROM payments WHERE 1=1"""
        params = []
        if status:
            sql += " AND payment_status=%s"
            params.append(status)
        if search:
            like = "%" + search + "%"
            sql += """ AND (payment_reference LIKE %s OR transaction_reference LIKE %s
                       OR patient_name LIKE %s OR patient_identifier LIKE %s OR department LIKE %s
                       OR service_name LIKE %s OR payment_method LIKE %s)"""
            params.extend([like] * 7)
        sql += " ORDER BY updated_at DESC LIMIT %s"
        params.append(limit)
        cur.execute(sql, tuple(params))
        rows = cur.fetchall()
        cur.close()
        for row in rows:
            for key in ("amount_expected", "amount_paid"):
                if row.get(key) is not None:
                    row[key] = str(row[key])
            for key in ("created_at", "updated_at"):
                if row.get(key):
                    row[key] = row[key].isoformat(sep=" ")
        return jsonify({"payments": rows})
    finally:
        conn.close()

@app.get("/api/reports/departments")
@login_required
def department_report():
    conn = db_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT COALESCE(department,'Unassigned') AS department,
                   COUNT(*) AS transaction_count,
                   COALESCE(SUM(amount_paid),0) AS revenue
            FROM payments
            WHERE payment_status='PAID'
            GROUP BY COALESCE(department,'Unassigned')
            ORDER BY revenue DESC
        """)
        rows = cur.fetchall()
        cur.close()
        return jsonify({"departments": [
            {"department": r["department"], "transaction_count": int(r["transaction_count"] or 0),
             "revenue": str(r["revenue"] or 0)} for r in rows
        ]})
    finally:
        conn.close()

@app.get("/api/reports/export.csv")
@login_required
def export_csv():
    import csv
    import io
    conn = db_connection()
    try:
        cur = conn.cursor()
        cur.execute("""SELECT payment_reference,transaction_reference,patient_name,patient_identifier,
                    department,service_name,amount_expected,amount_paid,currency,payment_method,
                    payment_status,paid_on,created_at FROM payments ORDER BY created_at DESC""")
        rows = cur.fetchall()
        output = __import__("io").StringIO()
        writer = csv.writer(output)
        writer.writerow(["Payment Reference","Transaction Reference","Patient","Patient ID","Department",
                         "Service","Expected","Paid","Currency","Method","Status","Paid On","Created At"])
        writer.writerows(rows)
        cur.close()
        response = make_response(output.getvalue())
        response.headers["Content-Type"] = "text/csv; charset=utf-8"
        response.headers["Content-Disposition"] = "attachment; filename=imsuth-payments.csv"
        return response
    finally:
        conn.close()

@app.errorhandler(500)
def server_error(error):
    app.logger.exception("Unhandled server error")
    return jsonify({"error": "Internal server error"}), 500

if __name__ == "__main__":
    if os.getenv("AUTO_INIT_DB", "true").lower() == "true":
        init_db()
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
