# IMSUTH Revenue Control — Python + MySQL + Monnify

A plain HTML/CSS/JavaScript frontend and Python Flask backend, designed to run under uWSGI with MySQL. The app initiates Monnify checkout, receives Monnify webhooks, verifies successful transactions server-to-server, stores payments idempotently, and updates the dashboard by polling the Python API.

## Important reality check

This is a runnable integration starter, not a production-certified hospital financial system. You must configure and test it with your own Monnify merchant account, bank settlement setup, domain/HTTPS, database, access controls, backups, and hospital approval before live collections. Do not enter live API keys into browser code. An API key alone is not enough: you also need the Monnify secret key and contract code. Monnify payment channels must be enabled on your merchant account.

The dashboard refreshes every 1.5 seconds. That is the UI refresh interval, not a guarantee that every payment appears within 1.5 seconds of a patient paying. Provider confirmation, webhook delivery, network and verification time affect end-to-end latency.

## Requirements

- Python 3.10+
- MySQL 8.x (or a compatible MySQL server)
- A public HTTPS domain for production webhooks
- Monnify merchant account, API key, secret key and contract code
- Linux VPS recommended for uWSGI deployment

## Local setup

1. Unzip this folder.
2. Create a MySQL database and app user. You can edit `schema.sql` first to replace its example database password, then run it with a MySQL administrator:
   ```bash
   mysql -u root -p < schema.sql
   ```
   The app also creates the required tables at startup when `AUTO_INIT_DB=true`.
3. Create a virtual environment and install requirements:
   ```bash
   python3 -m venv .venv
   source .venv/bin/activate
   pip install -r requirements.txt
   ```
4. Create your environment file:
   ```bash
   cp .env.example .env
   ```
5. Edit `.env`. Change `APP_SECRET_KEY`, `APP_PASSWORD`, MySQL password, Monnify credentials and `APP_BASE_URL`. Keep `MONNIFY_ENV=sandbox` initially.
6. Run for local testing:
   ```bash
   python app.py
   ```
7. Open `http://127.0.0.1:5000` and sign in using `APP_USERNAME` and `APP_PASSWORD` from `.env`.

## Monnify setup

1. Obtain the API key, secret key and contract code from your Monnify merchant dashboard.
2. Set the keys in the server-side `.env` file, not in HTML/JavaScript.
3. While testing, use `MONNIFY_ENV=sandbox`.
4. Configure the Transaction Completion webhook URL in Monnify as:
   `https://YOUR-DOMAIN/webhooks/monnify`
5. Make the app reachable publicly over HTTPS so Monnify can deliver webhook requests.
6. Run test payments for each payment method enabled on your merchant account and confirm that webhook events, verification and dashboard updates all work.
7. Before live mode, review the official Monnify go-live checklist and set `MONNIFY_ENV=live` with live credentials. Do not mix sandbox keys with live mode.
8. In production, confirm the webhook signature behaviour and network/IP filtering against the current official Monnify documentation. Do not disable signature validation for live traffic.

Official docs:
- https://developers.monnify.com/docs/collections/quickstart
- https://developers.monnify.com/docs/collections/manage-payments/verify-transactions
- https://developers.monnify.com/docs/webhooks
- https://developers.monnify.com/docs/live

## uWSGI and Nginx deployment outline

On a Linux VPS, install the system packages for Python, MySQL client libraries, Nginx and build tools required by uWSGI. Copy the app to `/opt/imsuth-revenue-control`, create the virtual environment, install `requirements.txt`, set up `.env` with restricted permissions, and configure MySQL.

Run uWSGI from the project directory:
```bash
.venv/bin/uwsgi --ini uwsgi.ini
```
The provided `uwsgi.ini` binds only to localhost port 5000. Configure Nginx using `deployment/nginx.conf`, update the domain and paths, then configure HTTPS. For production, run uWSGI under systemd and a non-root Linux user. Do not expose port 5000 directly to the internet.

## Webhook behaviour and data safety

- Successful transaction webhooks are signature-checked in live mode.
- The backend calls Monnify's transaction query endpoint before marking a payment as PAID.
- Duplicate webhook references are ignored.
- Payments with an amount mismatch against an app-created payment are marked REVIEW rather than counted as verified revenue.
- Payments originating in Monnify but created outside this app can be saved when Monnify confirms them; they will have no local department/service metadata unless separately mapped.
- The browser redirect never marks a payment as paid.
- The app records incoming webhook payloads for troubleshooting. These payloads may contain personal data; restrict database access and retention appropriately.
- The app does not automatically reconcile direct teller deposits or confirm bank settlement. Those require separate bank-statement or bank-API integration and reconciliation.
- No system can promise millisecond end-to-end display for every channel. This app polls every 1.5 seconds; provider and network latency still apply.

## Before production use

This starter has a single environment-configured admin login, not full hospital staff roles. Before production, add individual user accounts, role-based permissions, strong password policies, login throttling, secure secret management, monitoring/alerting, automated off-server backups, restore tests, audit review, data-protection review and independent security testing. Use a separate database account with least privilege. Do not store unnecessary clinical information in payment metadata.

## Troubleshooting

- `Configure Monnify...`: fill in API key, secret key and contract code in `.env`.
- MySQL connection errors: verify MySQL service, database, user, password, host and permissions.
- Webhook does not arrive locally: Monnify cannot call localhost; use a publicly reachable HTTPS URL or an approved test tunnel for sandbox only.
- Webhook returns 500: inspect server logs and the `webhook_events` table. Confirm server-to-server Monnify verification is reachable.
- Live signature failures: compare implementation against the current Monnify documentation and verify raw request bytes are used.


## Security hardening

Review `SECURITY_HARDENING.md` before any deployment. This starter still uses a single environment-configured login and does not yet implement individual accounts or role-based authorization; it is not safe for production patient/revenue data until those controls are completed and tested. This revision reduces data sent to Monnify metadata and hardens production secret handling. Use `AUTO_INIT_DB=false` in production and apply schema changes with a separate migration identity. Operational backup templates are in `deployment/` and must be configured, tested, and connected to encrypted off-server storage and alerting.
