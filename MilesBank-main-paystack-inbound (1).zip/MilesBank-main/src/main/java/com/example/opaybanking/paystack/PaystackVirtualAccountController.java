package com.example.opaybanking.paystack;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payments/paystack")
public class PaystackVirtualAccountController {
    private final PaystackVirtualAccountService service;

    public PaystackVirtualAccountController(PaystackVirtualAccountService service) { this.service = service; }

    @PostMapping("/virtual-account")
    public ResponseEntity<?> createVirtualAccount(@RequestHeader(value = "Authorization", required = false) String authorization) {
        if (authorization == null || !authorization.startsWith("Bearer ")) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("success", false, "message", "Bearer token required"));
        }
        try {
            return ResponseEntity.ok(service.createOrGetNgnVirtualAccount(authorization.substring(7)));
        } catch (IllegalStateException e) {
            return ResponseEntity.badRequest().body(Map.of("success", false, "message", e.getMessage()));
        }
    }

    @PostMapping("/webhook")
    public ResponseEntity<?> webhook(@RequestBody String rawBody,
                                     @RequestHeader(value = "x-paystack-signature", required = false) String signature) {
        if (!service.isValidWebhookSignature(rawBody, signature)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("success", false));
        }
        try {
            service.processWebhook(rawBody);
            return ResponseEntity.ok(Map.of("success", true));
        } catch (Exception e) {
            // Non-2xx makes Paystack retry; details are intentionally not returned to the caller.
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(Map.of("success", false));
        }
    }
}
