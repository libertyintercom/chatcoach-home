package com.example.opaybanking.paystack;

import com.example.opaybanking.enums.Currency;
import com.example.opaybanking.enums.Status;
import com.example.opaybanking.enums.TransactionType;
import com.example.opaybanking.model.*;
import com.example.opaybanking.repo.*;
import com.example.opaybanking.service.userService;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriUtils;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.Map;

@Service
public class PaystackVirtualAccountService {
    private final WalletRepo walletRepo;
    private final PaystackVirtualAccountRepo virtualAccountRepo;
    private final ProcessedPaystackPaymentRepo processedPaymentRepo;
    private final TransactionRepo transactionRepo;
    private final userService userService;
    private final RestTemplate restTemplate = new RestTemplate();
    private final ObjectMapper objectMapper = new ObjectMapper();

    @Value("${paystack.secret-key}") private String secretKey;
    @Value("${paystack.virtual-account.preferred-bank:test-bank}") private String preferredBank;

    public PaystackVirtualAccountService(WalletRepo walletRepo,
                                        PaystackVirtualAccountRepo virtualAccountRepo,
                                        ProcessedPaystackPaymentRepo processedPaymentRepo,
                                        TransactionRepo transactionRepo,
                                        userService userService) {
        this.walletRepo = walletRepo;
        this.virtualAccountRepo = virtualAccountRepo;
        this.processedPaymentRepo = processedPaymentRepo;
        this.transactionRepo = transactionRepo;
        this.userService = userService;
    }

    @Transactional
    public Map<String, Object> createOrGetNgnVirtualAccount(String jwt) {
        User user = userService.getAuthenticatedUser(jwt);
        Wallet wallet = walletRepo.findFirstByUserAndCurrency(user, Currency.NGN)
                .orElseThrow(() -> new IllegalStateException("Create your NGN wallet before requesting a deposit account"));

        var existing = virtualAccountRepo.findByWalletWalletId(wallet.getWalletId());
        if (existing.isPresent()) return toResponse(existing.get());
        if (user.getEmail() == null || user.getEmail().isBlank()) throw new IllegalStateException("A verified email is required");
        if (user.getFirstName() == null || user.getFirstName().isBlank() || user.getLastName() == null || user.getLastName().isBlank()) {
            throw new IllegalStateException("Your full name must be completed before requesting a deposit account");
        }

        Map<String, Object> customerRequest = new LinkedHashMap<>();
        customerRequest.put("email", user.getEmail());
        customerRequest.put("first_name", user.getFirstName());
        customerRequest.put("last_name", user.getLastName());
        if (user.getPhoneNumber() != null && !user.getPhoneNumber().isBlank()) customerRequest.put("phone", user.getPhoneNumber());
        JsonNode customerResponse = paystackPost("/customer", customerRequest);
        String customerCode = requiredText(customerResponse.path("data").path("customer_code"), "Paystack customer code");

        Map<String, Object> accountRequest = new LinkedHashMap<>();
        accountRequest.put("customer", customerCode);
        accountRequest.put("preferred_bank", preferredBank);
        JsonNode accountResponse = paystackPost("/dedicated_account", accountRequest);
        JsonNode data = accountResponse.path("data");
        String accountNumber = requiredText(data.path("account_number"), "virtual account number");
        String bankName = data.path("bank").path("name").asText("");
        String accountName = data.path("account_name").asText(user.getFirstName() + " " + user.getLastName());

        PaystackVirtualAccount account = new PaystackVirtualAccount();
        account.setWallet(wallet);
        account.setCustomerCode(customerCode);
        account.setAccountNumber(accountNumber);
        account.setBankName(bankName);
        account.setAccountName(accountName);
        account.setCurrency("NGN");
        return toResponse(virtualAccountRepo.save(account));
    }

    public boolean isValidWebhookSignature(String rawBody, String signature) {
        if (rawBody == null || signature == null || signature.isBlank() || secretKey == null || secretKey.isBlank()) return false;
        try {
            Mac mac = Mac.getInstance("HmacSHA512");
            mac.init(new SecretKeySpec(secretKey.getBytes(StandardCharsets.UTF_8), "HmacSHA512"));
            String expected = HexFormat.of().formatHex(mac.doFinal(rawBody.getBytes(StandardCharsets.UTF_8)));
            return MessageDigest.isEqual(expected.getBytes(StandardCharsets.US_ASCII), signature.toLowerCase().getBytes(StandardCharsets.US_ASCII));
        } catch (Exception e) {
            return false;
        }
    }

    @Transactional
    public void processWebhook(String rawBody) {
        try {
            JsonNode root = objectMapper.readTree(rawBody);
            if (!"charge.success".equals(root.path("event").asText())) return;
            JsonNode eventData = root.path("data");
            String reference = requiredText(eventData.path("reference"), "transaction reference");
            if (processedPaymentRepo.existsByReference(reference)) return;

            // Verify the reference directly with Paystack; never credit solely from the webhook body.
            JsonNode verified = paystackGet("/transaction/verify/" + UriUtils.encodePathSegment(reference, StandardCharsets.UTF_8));
            JsonNode data = verified.path("data");
            if (!"success".equalsIgnoreCase(data.path("status").asText())) return;
            if (!"NGN".equalsIgnoreCase(data.path("currency").asText())) return;
            long amountKobo = data.path("amount").asLong(-1);
            if (amountKobo <= 0) return;
            String customerCode = data.path("customer").path("customer_code").asText("");
            if (customerCode.isBlank()) customerCode = eventData.path("customer").path("customer_code").asText("");
            if (customerCode.isBlank()) return;

            PaystackVirtualAccount virtualAccount = virtualAccountRepo.findByCustomerCode(customerCode).orElse(null);
            if (virtualAccount == null) return; // Do not credit payments not mapped to a MilesBank wallet.
            Wallet wallet = walletRepo.findByWalletIdForUpdate(virtualAccount.getWallet().getWalletId()).orElseThrow();
            if (processedPaymentRepo.existsByReference(reference)) return;

            BigDecimal amount = BigDecimal.valueOf(amountKobo).divide(BigDecimal.valueOf(100), 2, RoundingMode.UNNECESSARY);
            BigDecimal oldBalance = BigDecimal.valueOf(wallet.getBalance());
            wallet.setBalance(oldBalance.add(amount).doubleValue());
            walletRepo.save(wallet);

            Transaction transaction = new Transaction();
            transaction.setUser(wallet.getUser());
            transaction.setWallet(wallet);
            transaction.setAmount(amount.doubleValue());
            transaction.setTransactionType(TransactionType.DEPOSIT);
            transaction.setReference(reference);
            transaction.setTransactionStatus(Status.SUCCESSFUL);
            transaction.setDescription("Incoming bank transfer via Paystack");
            transaction.setCreatedAt(LocalDateTime.now());
            transactionRepo.save(transaction);

            processedPaymentRepo.save(new ProcessedPaystackPayment(reference));
        } catch (RestClientResponseException e) {
            throw new IllegalStateException("Unable to verify Paystack payment", e);
        } catch (Exception e) {
            throw new IllegalStateException("Could not process Paystack webhook", e);
        }
    }

    private JsonNode paystackPost(String path, Map<String, Object> body) {
        HttpHeaders headers = headers();
        try {
            ResponseEntity<String> response = restTemplate.exchange("https://api.paystack.co" + path,
                    HttpMethod.POST, new HttpEntity<>(body, headers), String.class);
            JsonNode json = objectMapper.readTree(response.getBody());
            if (!json.path("status").asBoolean(false)) throw new IllegalStateException("Paystack rejected the request: " + json.path("message").asText("unknown error"));
            return json;
        } catch (RestClientResponseException e) {
            throw new IllegalStateException("Paystack API request failed with HTTP " + e.getStatusCode().value(), e);
        } catch (Exception e) {
            if (e instanceof IllegalStateException) throw (IllegalStateException) e;
            throw new IllegalStateException("Could not parse Paystack response", e);
        }
    }

    private JsonNode paystackGet(String path) {
        try {
            ResponseEntity<String> response = restTemplate.exchange("https://api.paystack.co" + path,
                    HttpMethod.GET, new HttpEntity<>(headers()), String.class);
            JsonNode json = objectMapper.readTree(response.getBody());
            if (!json.path("status").asBoolean(false)) throw new IllegalStateException("Paystack verification failed");
            return json;
        } catch (RestClientResponseException e) {
            throw new IllegalStateException("Paystack verification API failed with HTTP " + e.getStatusCode().value(), e);
        } catch (Exception e) {
            if (e instanceof IllegalStateException) throw (IllegalStateException) e;
            throw new IllegalStateException("Could not parse Paystack verification response", e);
        }
    }

    private HttpHeaders headers() {
        HttpHeaders headers = new HttpHeaders();
        headers.setBearerAuth(secretKey);
        headers.setContentType(MediaType.APPLICATION_JSON);
        return headers;
    }

    private String requiredText(JsonNode node, String field) {
        String value = node.asText("");
        if (value.isBlank()) throw new IllegalStateException("Paystack response missing " + field);
        return value;
    }

    private Map<String, Object> toResponse(PaystackVirtualAccount account) {
        Map<String, Object> response = new LinkedHashMap<>();
        response.put("success", true);
        response.put("message", "Use this dedicated account to receive NGN bank transfers. Credits appear after Paystack confirms the transfer.");
        response.put("accountNumber", account.getAccountNumber());
        response.put("accountName", account.getAccountName());
        response.put("bankName", account.getBankName());
        response.put("currency", account.getCurrency());
        return response;
    }
}
