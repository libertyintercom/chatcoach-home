package com.example.opaybanking.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "paystack_virtual_account", uniqueConstraints = {
        @UniqueConstraint(name = "uk_paystack_va_wallet", columnNames = "wallet_id"),
        @UniqueConstraint(name = "uk_paystack_va_customer_code", columnNames = "customer_code"),
        @UniqueConstraint(name = "uk_paystack_va_account_number", columnNames = "account_number")
})
public class PaystackVirtualAccount {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "wallet_id", nullable = false)
    private Wallet wallet;

    @Column(name = "customer_code", nullable = false, length = 100)
    private String customerCode;

    @Column(name = "account_number", nullable = false, length = 20)
    private String accountNumber;

    @Column(name = "account_name", length = 180)
    private String accountName;

    @Column(name = "bank_name", length = 120)
    private String bankName;

    @Column(nullable = false, length = 10)
    private String currency = "NGN";

    @Column(nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();

    public Long getId() { return id; }
    public Wallet getWallet() { return wallet; }
    public void setWallet(Wallet wallet) { this.wallet = wallet; }
    public String getCustomerCode() { return customerCode; }
    public void setCustomerCode(String customerCode) { this.customerCode = customerCode; }
    public String getAccountNumber() { return accountNumber; }
    public void setAccountNumber(String accountNumber) { this.accountNumber = accountNumber; }
    public String getAccountName() { return accountName; }
    public void setAccountName(String accountName) { this.accountName = accountName; }
    public String getBankName() { return bankName; }
    public void setBankName(String bankName) { this.bankName = bankName; }
    public String getCurrency() { return currency; }
    public void setCurrency(String currency) { this.currency = currency; }
    public LocalDateTime getCreatedAt() { return createdAt; }
}
