package com.example.opaybanking.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "processed_paystack_payment", uniqueConstraints =
        @UniqueConstraint(name = "uk_processed_paystack_reference", columnNames = "reference"))
public class ProcessedPaystackPayment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 120)
    private String reference;

    @Column(nullable = false)
    private LocalDateTime processedAt = LocalDateTime.now();

    protected ProcessedPaystackPayment() {}
    public ProcessedPaystackPayment(String reference) { this.reference = reference; }
    public String getReference() { return reference; }
    public LocalDateTime getProcessedAt() { return processedAt; }
}
