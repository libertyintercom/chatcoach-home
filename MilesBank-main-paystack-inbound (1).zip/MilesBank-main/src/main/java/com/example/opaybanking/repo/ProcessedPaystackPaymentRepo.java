package com.example.opaybanking.repo;

import com.example.opaybanking.model.ProcessedPaystackPayment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProcessedPaystackPaymentRepo extends JpaRepository<ProcessedPaystackPayment, Long> {
    boolean existsByReference(String reference);
}
