package com.example.opaybanking.repo;

import com.example.opaybanking.model.PaystackVirtualAccount;
import com.example.opaybanking.model.Wallet;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.Optional;

public interface PaystackVirtualAccountRepo extends JpaRepository<PaystackVirtualAccount, Long> {
    Optional<PaystackVirtualAccount> findByWalletWalletId(Long walletId);
    Optional<PaystackVirtualAccount> findByCustomerCode(String customerCode);
}
