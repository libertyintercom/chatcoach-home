"""Re-verify PENDING payments with Paystack (safety net for missed webhooks).
Run by the imsuth-reconcile systemd timer every 5 minutes.
Usage: python reconcile.py [min_age_minutes]
"""
import json
import sys

from app import reconcile_pending

if __name__ == "__main__":
    minutes = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    print(json.dumps(reconcile_pending(min_age_minutes=minutes)))
