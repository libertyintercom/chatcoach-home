import os
import re
import csv
import io
import json
import hmac
import hashlib
import secrets
from decimal import Decimal, InvalidOperation
from functools import wraps
from datetime import datetime, timezone, timedelta
from urllib.parse import quote

import requests
import mysql.connector
from mysql.connector import pooling
from flask import Flask, request, jsonify, render_template, session, make_response
from werkzeug.middleware.proxy_fix import ProxyFix
from dotenv import load_dotenv

load_dotenv()

APP_ENV = os.getenv("APP_ENV", "development").lower()

app = Flask(__name__)
# uWSGI listens on 127.0.0.1 only; Nginx is the single trusted proxy in front of it.
app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1, x_host=1)

_app_secret = os.getenv("APP_SECRET_KEY", "").strip()
if not _app_secret or _app_secret.startswith("CHANGE-ME"):
    if APP_ENV == "production":
        raise RuntimeError("APP_SECRET_KEY must be set to a long random value in production")
    _app_secret = secrets.token_urlsafe(48)
app.secret_key = _app_secret
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.getenv("COOKIE_SECURE", "true").lower() == "true",
    PERMANENT_SESSION_LIFETIME=timedelta(hours=8),
)

# ---------------------------------------------------------------- Paystack config
PAYSTACK_BASE_URL = "https://api.paystack.co"
PAYSTACK_SECRET_KEY = os.getenv("PAYSTACK_SECRET_KEY", "").strip()
# Paystack decides test vs live by the key itself (sk_test_... / sk_live_...).
PAYSTACK_MODE = "live" if PAYSTACK_SECRET_KEY.startswith("sk_live_") else "test"
PAYSTACK_FALLBACK_EMAIL = os.getenv("PAYSTACK_FALLBACK_EMAIL", "").strip()
if APP_ENV == "production" and not PAYSTACK_SECRET_KEY.startswith("sk_live_"):
    raise RuntimeError("APP_ENV=production requires a live Paystack secret key (sk_live_...). "
                       "Use APP_ENV=staging while testing with sk_test_ keys.")

APP_BASE_URL = os.getenv("APP_BASE_URL", "http://127.0.0.1:5000").rstrip("/")
APP_USERNAME = os.getenv("APP_USERNAME", "admin")
APP_PASSWORD = os.getenv("APP_PASSWORD", "CHANGE-ME-now")
HOSPITAL_NAME = os.getenv("HOSPITAL_NAME", "IMSUTH PAYPOINT")
REFERENCE_RE = re.compile(r"^[A-Za-z0-9._=-]{1,120}$")

pool = None


def get_pool():
    global pool
    if pool is None:
        pool = pooling.MySQLConnectionPool(
            pool_name="imsuth_pool",
            pool_size=int(os.getenv("MYSQL_POOL_SIZE", "5")),
            host=os.getenv("MYSQL_HOST", "127.0.0.1"),
            port=int(os.getenv("MYSQL_PORT", "3306")),
            user=os.getenv("MYSQL_USER", "imsuth_app"),
            password=os.getenv("MYSQL_PASSWORD", ""),
            database=os.getenv("MYSQL_DATABASE", "imsuth_revenue"),
            autocommit=False,
            connection_timeout=8,
        )
    return pool


def db_connection():
    return get_pool().get_connection()


def init_db():
    """Create tables (development only; production uses schema.sql with AUTO_INIT_DB=false)."""
    here = os.path.dirname(os.path.abspath(__file__))
    with open(os.path.join(here, "schema.sql"), encoding="utf-8") as fh:
        sql = fh.read()
    statements = [s.strip() for s in sql.split(";") if s.strip()
                  and not s.strip().upper().startswith(("CREATE DATABASE", "USE "))]
    conn = db_connection()
    try:
        cur = conn.cursor()
        for statement in statements:
            cur.execute(statement)
        conn.commit()
        cur.close()
    finally:
        conn.close()


def log_audit(actor, action, detail=None):
    conn = db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "INSERT INTO audit_log (actor, action, detail) VALUES (%s, %s, %s)",
            (actor, action, json.dumps(detail or {}, default=str)),
        )
        conn.commit()
        cur.close()
    finally:
        conn.close()


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("authenticated"):
            return jsonify({"error": "Authentication required"}), 401
        return fn(*args, **kwargs)
    return wrapped


@app.before_request
def csrf_guard():
    if request.method in ("POST", "PUT", "PATCH", "DELETE"):
        if request.path in ("/webhooks/paystack", "/api/login"):
            return None
        if session.get("authenticated"):
            expected = session.get("csrf_token", "")
            supplied = request.headers.get("X-CSRF-Token", "")
            if not expected or not hmac.compare_digest(expected, supplied):
                return jsonify({"error": "Invalid CSRF token"}), 403


@app.after_request
def security_headers(resp):
    resp.headers.setdefault("X-Content-Type-Options", "nosniff")
    resp.headers.setdefault("X-Frame-Options", "DENY")
    resp.headers.setdefault("Referrer-Policy", "same-origin")
    if app.config["SESSION_COOKIE_SECURE"]:
        resp.headers.setdefault("Strict-Transport-Security", "max-age=31536000")
    if request.path.startswith("/api/"):
        resp.headers.setdefault("Cache-Control", "no-store")
    return resp


@app.get("/")
def index():
    if not session.get("authenticated"):
        return render_template("login.html", hospital_name=HOSPITAL_NAME)
    return render_template("dashboard.html", hospital_name=HOSPITAL_NAME)


@app.get("/health")
def health():
    return jsonify({"ok": True, "service": "imsuth-revenue-control"})


@app.post("/api/login")
def api_login():
    data = request.get_json(silent=True) or {}
    username = str(data.get("username", ""))
    password = str(data.get("password", ""))
    valid_user = hmac.compare_digest(username, APP_USERNAME)
    valid_password = hmac.compare_digest(password, APP_PASSWORD)
    if not valid_user or not valid_password:
        return jsonify({"error": "Invalid username or password"}), 401
    session.clear()
    session["authenticated"] = True
    session["username"] = username
    session["csrf_token"] = secrets.token_urlsafe(32)
    session.permanent = True
    log_audit(username, "LOGIN", {"source": request.remote_addr})
    return jsonify({"ok": True, "csrf_token": session["csrf_token"]})


@app.post("/api/logout")
@login_required
def api_logout():
    username = session.get("username", "unknown")
    log_audit(username, "LOGOUT")
    session.clear()
    return jsonify({"ok": True})


@app.get("/api/session")
@login_required
def api_session():
    return jsonify({
        "username": session.get("username"),
        "csrf_token": session.get("csrf_token"),
        "hospital_name": HOSPITAL_NAME,
        "environment": PAYSTACK_MODE,
    })


# ---------------------------------------------------------------- Paystack helpers
def paystack_request(method, path, **kwargs):
    if not PAYSTACK_SECRET_KEY:
        raise RuntimeError("Set PAYSTACK_SECRET_KEY in the environment file")
    response = requests.request(
        method,
        PAYSTACK_BASE_URL + path,
        headers={"Authorization": "Bearer " + PAYSTACK_SECRET_KEY, "Content-Type": "application/json"},
        timeout=(3.05, 15),
        **kwargs,
    )
    try:
        body = response.json()
    except ValueError:
        response.raise_for_status()
        raise RuntimeError("Paystack returned a non-JSON response")
    return response.status_code, body


def verify_paystack_payment(reference):
    """Server-to-server check. This, not the webhook body, decides whether money was received."""
    status, body = paystack_request("GET", "/transaction/verify/" + quote(reference, safe=""))
    if status >= 400 or not body.get("status"):
        raise RuntimeError("Paystack verify failed: " + str(body.get("message", status))[:200])
    return body.get("data") or {}


def kobo_to_naira(value):
    return (Decimal(int(value)) / Decimal(100)).quantize(Decimal("0.01"))


@app.post("/api/payments/initiate")
@login_required
def initiate_payment():
    data = request.get_json(silent=True) or {}
    try:
        amount = Decimal(str(data.get("amount", "")).replace(",", "")).quantize(Decimal("0.01"))
    except (InvalidOperation, ValueError):
        return jsonify({"error": "Enter a valid amount"}), 400
    if amount < 1 or amount > Decimal("100000000"):
        return jsonify({"error": "Amount must be at least 1 and within the allowed limit"}), 400
    if not PAYSTACK_SECRET_KEY:
        return jsonify({"error": "Set PAYSTACK_SECRET_KEY in the server environment first"}), 503

    patient_name = str(data.get("patient_name", "")).strip()[:180]
    patient_identifier = str(data.get("patient_identifier", "")).strip()[:100]
    email = str(data.get("email", "")).strip()[:254]
    department = str(data.get("department", "")).strip()[:120]
    service_name = str(data.get("service_name", "")).strip()[:180]
    if not patient_name or not service_name or not department:
        return jsonify({"error": "Patient name, department and service are required"}), 400
    if email and ("@" not in email or " " in email):
        return jsonify({"error": "Enter a valid email address or leave it blank"}), 400
    paystack_email = email or PAYSTACK_FALLBACK_EMAIL
    if not paystack_email:
        return jsonify({"error": "Customer email is required (or set PAYSTACK_FALLBACK_EMAIL)"}), 400

    payment_reference = "IMSUTH-" + datetime.now(timezone.utc).strftime("%Y%m%d%H%M%S") + "-" + secrets.token_hex(5).upper()

    conn = db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            """INSERT INTO payments
               (payment_reference, patient_name, patient_identifier, customer_email,
                department, service_name, amount_expected, amount_paid, currency,
                payment_status, paystack_mode)
               VALUES (%s,%s,%s,%s,%s,%s,%s,0.00,'NGN','PENDING',%s)""",
            (payment_reference, patient_name, patient_identifier, email or None,
             department, service_name, str(amount), PAYSTACK_MODE),
        )
        conn.commit()
        cur.close()
    finally:
        conn.close()

    payload = {
        "email": paystack_email,
        "amount": int((amount * 100).to_integral_value()),  # Paystack uses kobo
        "currency": "NGN",
        "reference": payment_reference,
        "callback_url": APP_BASE_URL + "/payment-return",
        "channels": ["card", "bank", "ussd", "bank_transfer"],
        # Keep clinical/patient details out of provider metadata; mapping stays local.
        "metadata": {"hospital": HOSPITAL_NAME, "payment_reference": payment_reference},
    }
    try:
        status, result = paystack_request("POST", "/transaction/initialize", json=payload)
        if status >= 400 or not result.get("status"):
            raise RuntimeError(str(result.get("message", "Paystack rejected initialization")))
        checkout_url = (result.get("data") or {}).get("authorization_url")
        if not checkout_url:
            raise RuntimeError("Paystack did not return an authorization URL")
        conn = db_connection()
        try:
            cur = conn.cursor()
            cur.execute("UPDATE payments SET checkout_url=%s WHERE payment_reference=%s",
                        (checkout_url, payment_reference))
            conn.commit()
            cur.close()
        finally:
            conn.close()
        log_audit(session.get("username", "unknown"), "PAYMENT_INITIATED",
                  {"payment_reference": payment_reference, "amount": str(amount)})
        return jsonify({"ok": True, "payment_reference": payment_reference, "checkout_url": checkout_url})
    except Exception:
        app.logger.exception("Paystack initialization failed")
        return jsonify({"error": "Could not start the payment with Paystack. Check server logs."}), 502


@app.get("/payment-return")
def payment_return():
    # Display-only page. It never confirms payment; the webhook + verify call does.
    return render_template("return.html", hospital_name=HOSPITAL_NAME)


# ---------------------------------------------------------------- settlement (shared)
def settle_payment(reference, payload, event_key=None, _retry=True):
    """Verify with Paystack and record the result. Idempotent.

    Returns {"state": "PAID" | "REVIEW" | <paystack status such as failed/abandoned>}.
    Raises on anything unexpected so the caller can return non-200 and Paystack retries.
    """
    if not REFERENCE_RE.match(reference or ""):
        raise RuntimeError("Invalid payment reference")
    verified = verify_paystack_payment(reference)
    pstatus = str(verified.get("status", "")).lower()
    if pstatus != "success":
        return {"state": pstatus or "unknown"}
    if str(verified.get("reference", "")) != reference:
        raise RuntimeError("Reference mismatch in Paystack verify response")
    currency = str(verified.get("currency") or "").upper()
    if currency != "NGN":
        raise RuntimeError("Unexpected currency: " + currency)
    amount = kobo_to_naira(verified.get("amount"))
    if amount <= 0:
        raise RuntimeError("Verified amount is not positive")

    transaction_id = str(verified.get("id") or "") or None
    channel = str(verified.get("channel") or "unknown")
    paid_on = str(verified.get("paid_at") or "")
    customer = verified.get("customer") or {}
    customer_email = customer.get("email")
    customer_name = " ".join(p for p in (customer.get("first_name"), customer.get("last_name")) if p) or None
    raw = json.dumps(payload, default=str)

    conn = db_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute("SELECT * FROM payments WHERE payment_reference=%s FOR UPDATE", (reference,))
        existing = cur.fetchone()

        if existing and existing["payment_status"] == "PAID":
            state = "PAID"
        elif existing and existing.get("amount_expected") is not None \
                and Decimal(str(existing["amount_expected"])).quantize(Decimal("0.01")) != amount:
            cur.execute(
                """UPDATE payments SET payment_status='REVIEW', amount_paid=%s, transaction_reference=%s,
                   payment_method=%s, paid_on=%s, raw_event=%s WHERE payment_reference=%s""",
                (str(amount), transaction_id, channel, paid_on, raw, reference),
            )
            state = "REVIEW"
        elif existing:
            cur.execute(
                """UPDATE payments SET transaction_reference=%s,
                   patient_name=COALESCE(patient_name,%s), customer_email=COALESCE(customer_email,%s),
                   amount_paid=%s, currency='NGN', payment_method=%s, payment_status='PAID',
                   paid_on=%s, raw_event=%s WHERE payment_reference=%s""",
                (transaction_id, customer_name, customer_email, str(amount), channel, paid_on, raw, reference),
            )
            state = "PAID"
        else:
            # Money received into the Paystack account that this app did not create
            # (e.g. dedicated virtual account transfer, payment page, invoice).
            cur.execute(
                """INSERT INTO payments
                   (payment_reference,transaction_reference,patient_name,customer_email,
                    amount_expected,amount_paid,currency,payment_method,payment_status,
                    paid_on,paystack_mode,raw_event)
                   VALUES (%s,%s,%s,%s,NULL,%s,'NGN',%s,'PAID',%s,%s,%s)""",
                (reference, transaction_id, customer_name, customer_email, str(amount),
                 channel, paid_on, PAYSTACK_MODE, raw),
            )
            state = "PAID"

        if event_key:
            cur.execute(
                """UPDATE webhook_events SET processing_status=%s, error_message=%s, processed_at=NOW()
                   WHERE event_key=%s""",
                ("REVIEW" if state == "REVIEW" else "PROCESSED",
                 "Amount differs from expected amount" if state == "REVIEW" else None, event_key),
            )
        conn.commit()
        cur.close()
        return {"state": state}
    except mysql.connector.IntegrityError:
        conn.rollback()
        if _retry:  # a concurrent delivery inserted the same reference first
            conn.close()
            conn = None
            return settle_payment(reference, payload, event_key, _retry=False)
        raise
    finally:
        if conn is not None:
            conn.close()


def reconcile_pending(min_age_minutes=10, max_age_days=3, limit=200):
    """Safety net for missed webhooks: re-verify PENDING payments with Paystack."""
    conn = db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            """SELECT payment_reference FROM payments
               WHERE payment_status='PENDING'
                 AND created_at < NOW() - INTERVAL %s MINUTE
                 AND created_at > NOW() - INTERVAL %s DAY
               ORDER BY created_at LIMIT %s""",
            (int(min_age_minutes), int(max_age_days), int(limit)),
        )
        refs = [r[0] for r in cur.fetchall()]
        cur.close()
    finally:
        conn.close()
    summary = {"checked": len(refs), "paid": 0, "review": 0, "failed": 0, "errors": 0}
    for ref in refs:
        try:
            result = settle_payment(ref, {"source": "reconcile"})
            if result["state"] == "PAID":
                summary["paid"] += 1
            elif result["state"] == "REVIEW":
                summary["review"] += 1
            elif result["state"] in ("failed", "reversed"):
                c = db_connection()
                try:
                    k = c.cursor()
                    k.execute("UPDATE payments SET payment_status='FAILED' "
                              "WHERE payment_reference=%s AND payment_status='PENDING'", (ref,))
                    c.commit()
                    k.close()
                finally:
                    c.close()
                summary["failed"] += 1
        except Exception as exc:  # e.g. customer never opened checkout -> Paystack 404
            summary["errors"] += 1
            app.logger.info("Reconcile skipped %s: %s", ref, exc)
    log_audit("system", "RECONCILE", summary)
    return summary


# ---------------------------------------------------------------- webhook
def validate_webhook_signature(raw_body):
    signature = request.headers.get("x-paystack-signature", "").strip().lower()
    if not signature or not PAYSTACK_SECRET_KEY:
        return False
    expected = hmac.new(PAYSTACK_SECRET_KEY.encode("utf-8"), raw_body, hashlib.sha512).hexdigest()
    return hmac.compare_digest(expected, signature)


def _set_event_status(event_key, status, error=None):
    conn = db_connection()
    try:
        cur = conn.cursor()
        cur.execute(
            "UPDATE webhook_events SET processing_status=%s, error_message=%s, processed_at=NOW() WHERE event_key=%s",
            (status, error, event_key),
        )
        conn.commit()
        cur.close()
    finally:
        conn.close()


@app.post("/webhooks/paystack")
def paystack_webhook():
    raw = request.get_data(cache=True)
    if not validate_webhook_signature(raw):
        app.logger.warning("Rejected Paystack webhook with missing/invalid signature")
        return jsonify({"error": "Invalid signature"}), 401
    try:
        payload = json.loads(raw.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return jsonify({"error": "Invalid JSON"}), 400

    event_type = str(payload.get("event", "UNKNOWN"))
    data = payload.get("data") or {}
    reference = str(data.get("reference", "")).strip()
    paystack_id = str(data.get("id", "")).strip()
    event_key = (event_type + ":" + (paystack_id or reference or hashlib.sha256(raw).hexdigest()))[:190]

    conn = db_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute(
            """INSERT IGNORE INTO webhook_events
               (event_key,event_type,payment_reference,payload,processing_status)
               VALUES (%s,%s,%s,%s,'RECEIVED')""",
            (event_key, event_type, reference or None, json.dumps(payload, default=str)),
        )
        inserted = cur.rowcount == 1
        previous_status = None
        if not inserted:
            cur.execute("SELECT processing_status FROM webhook_events WHERE event_key=%s", (event_key,))
            row = cur.fetchone()
            previous_status = (row or {}).get("processing_status")
        conn.commit()
        cur.close()
    finally:
        conn.close()

    # Finished before -> acknowledge. Failed/incomplete before -> process again (Paystack retries).
    if not inserted and previous_status in ("PROCESSED", "IGNORED", "REVIEW"):
        return jsonify({"ok": True, "duplicate": True}), 200

    try:
        if event_type != "charge.success":
            _set_event_status(event_key, "IGNORED")
            return jsonify({"ok": True, "ignored": True}), 200
        if not reference:
            raise RuntimeError("Webhook has no reference")
        result = settle_payment(reference, payload, event_key)
        if result["state"] not in ("PAID", "REVIEW"):
            raise RuntimeError("Paystack verify did not confirm success (status: %s)" % result["state"])
        return jsonify({"ok": True, "review_required": result["state"] == "REVIEW"}), 200
    except Exception as exc:
        app.logger.exception("Webhook processing failed")
        _set_event_status(event_key, "ERROR", str(exc)[:480])
        return jsonify({"error": "Webhook could not be fully processed"}), 500


# ---------------------------------------------------------------- dashboard API
@app.get("/api/dashboard/summary")
@login_required
def dashboard_summary():
    conn = db_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT
              COALESCE(SUM(CASE WHEN payment_status='PAID' AND DATE(updated_at)=CURDATE() THEN amount_paid ELSE 0 END),0) AS today_revenue,
              COALESCE(SUM(CASE WHEN payment_status='PAID' THEN amount_paid ELSE 0 END),0) AS total_paid,
              SUM(CASE WHEN payment_status='PAID' THEN 1 ELSE 0 END) AS successful_count,
              SUM(CASE WHEN payment_status='PENDING' THEN 1 ELSE 0 END) AS pending_count,
              SUM(CASE WHEN payment_status='REVIEW' THEN 1 ELSE 0 END) AS review_count
            FROM payments
        """)
        row = cur.fetchone() or {}
        cur.close()
        return jsonify({k: str(v or 0) for k, v in row.items()})
    finally:
        conn.close()


@app.get("/api/payments")
@login_required
def list_payments():
    try:
        limit = min(max(int(request.args.get("limit", "100")), 1), 500)
    except ValueError:
        limit = 100
    search = request.args.get("q", "").strip()[:120]
    status = request.args.get("status", "").strip().upper()[:40]
    conn = db_connection()
    try:
        cur = conn.cursor(dictionary=True)
        sql = """SELECT id,payment_reference,transaction_reference,patient_name,patient_identifier,
                 customer_email,department,service_name,amount_expected,amount_paid,currency,
                 payment_method,payment_status,paid_on,created_at,updated_at
                 FROM payments WHERE 1=1"""
        params = []
        if status:
            sql += " AND payment_status=%s"
            params.append(status)
        if search:
            like = "%" + search + "%"
            sql += """ AND (payment_reference LIKE %s OR transaction_reference LIKE %s
                       OR patient_name LIKE %s OR patient_identifier LIKE %s OR department LIKE %s
                       OR service_name LIKE %s OR payment_method LIKE %s)"""
            params.extend([like] * 7)
        sql += " ORDER BY updated_at DESC LIMIT %s"
        params.append(limit)
        cur.execute(sql, tuple(params))
        rows = cur.fetchall()
        cur.close()
        for row in rows:
            for key in ("amount_expected", "amount_paid"):
                if row.get(key) is not None:
                    row[key] = str(row[key])
            for key in ("created_at", "updated_at"):
                if row.get(key):
                    row[key] = row[key].isoformat(sep=" ")
        return jsonify({"payments": rows})
    finally:
        conn.close()


@app.get("/api/reports/departments")
@login_required
def department_report():
    conn = db_connection()
    try:
        cur = conn.cursor(dictionary=True)
        cur.execute("""
            SELECT COALESCE(department,'Unassigned') AS department,
                   COUNT(*) AS transaction_count,
                   COALESCE(SUM(amount_paid),0) AS revenue
            FROM payments
            WHERE payment_status='PAID'
            GROUP BY COALESCE(department,'Unassigned')
            ORDER BY revenue DESC
        """)
        rows = cur.fetchall()
        cur.close()
        return jsonify({"departments": [
            {"department": r["department"], "transaction_count": int(r["transaction_count"] or 0),
             "revenue": str(r["revenue"] or 0)} for r in rows
        ]})
    finally:
        conn.close()


@app.get("/api/reports/export.csv")
@login_required
def export_csv():
    conn = db_connection()
    try:
        cur = conn.cursor()
        cur.execute("""SELECT payment_reference,transaction_reference,patient_name,patient_identifier,
                    department,service_name,amount_expected,amount_paid,currency,payment_method,
                    payment_status,paid_on,created_at FROM payments ORDER BY created_at DESC""")
        rows = cur.fetchall()
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["Payment Reference", "Transaction ID", "Patient", "Patient ID", "Department",
                         "Service", "Expected", "Paid", "Currency", "Channel", "Status", "Paid On", "Created At"])
        writer.writerows(rows)
        cur.close()
        log_audit(session.get("username", "unknown"), "EXPORT_CSV", {"rows": len(rows)})
        response = make_response(output.getvalue())
        response.headers["Content-Type"] = "text/csv; charset=utf-8"
        response.headers["Content-Disposition"] = "attachment; filename=imsuth-payments.csv"
        return response
    finally:
        conn.close()


@app.errorhandler(500)
def server_error(error):
    app.logger.exception("Unhandled server error")
    return jsonify({"error": "Internal server error"}), 500


if __name__ == "__main__":
    if os.getenv("AUTO_INIT_DB", "false").lower() == "true":
        init_db()
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)
