-- ONLY for a database that was created by the previous Monnify version.
-- Fresh installs use schema.sql and do NOT need this file.
-- Take a backup first:  mysqldump --single-transaction imsuth_revenue | gzip > before-paystack.sql.gz
USE imsuth_revenue;
ALTER TABLE payments
  CHANGE COLUMN monnify_environment paystack_mode VARCHAR(12) NOT NULL DEFAULT 'test',
  MODIFY COLUMN transaction_reference VARCHAR(120) NULL COMMENT 'Paystack transaction id',
  MODIFY COLUMN payment_method VARCHAR(60) NULL COMMENT 'Paystack channel';
-- Old Monnify 'sandbox' rows are test data; mark them so they are easy to find/remove.
UPDATE payments SET paystack_mode='test' WHERE paystack_mode='sandbox';
UPDATE payments SET paystack_mode='live'  WHERE paystack_mode='live';
