-- Run as the MySQL administrator (sudo mysql < schema.sql). Creates database and tables only.
-- The runtime user (imsuth_app) is created separately with least-privilege grants;
-- see INSTALL_UBUNTU24.md.
CREATE DATABASE IF NOT EXISTS imsuth_revenue
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE imsuth_revenue;

CREATE TABLE IF NOT EXISTS payments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  payment_reference VARCHAR(120) NOT NULL,
  transaction_reference VARCHAR(120) NULL COMMENT 'Paystack transaction id',
  patient_name VARCHAR(180) NULL,
  patient_identifier VARCHAR(100) NULL,
  customer_email VARCHAR(254) NULL,
  department VARCHAR(120) NULL,
  service_name VARCHAR(180) NULL,
  amount_expected DECIMAL(14,2) NULL,
  amount_paid DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  currency CHAR(3) NOT NULL DEFAULT 'NGN',
  payment_method VARCHAR(60) NULL COMMENT 'Paystack channel: card, bank_transfer, ussd, bank, dedicated_nuban...',
  payment_status VARCHAR(40) NOT NULL DEFAULT 'PENDING',
  paid_on VARCHAR(80) NULL,
  paystack_mode VARCHAR(12) NOT NULL DEFAULT 'test',
  checkout_url TEXT NULL,
  raw_event JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_payment_reference (payment_reference),
  UNIQUE KEY uq_transaction_reference (transaction_reference),
  KEY ix_payment_status (payment_status),
  KEY ix_created_at (created_at),
  KEY ix_department (department)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS webhook_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  event_key VARCHAR(190) NOT NULL,
  event_type VARCHAR(100) NULL,
  payment_reference VARCHAR(120) NULL,
  received_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  processed_at TIMESTAMP NULL,
  processing_status VARCHAR(40) NOT NULL DEFAULT 'RECEIVED',
  error_message VARCHAR(500) NULL,
  payload JSON NOT NULL,
  UNIQUE KEY uq_webhook_event_key (event_key),
  KEY ix_webhook_received (received_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
  actor VARCHAR(100) NOT NULL,
  action VARCHAR(100) NOT NULL,
  detail JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY ix_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
