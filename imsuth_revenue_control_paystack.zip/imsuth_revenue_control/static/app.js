let csrfToken = '';
let lastPaymentIds = new Set();

const naira = value => '₦' + Number(value || 0).toLocaleString('en-NG', {minimumFractionDigits:2, maximumFractionDigits:2});
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

async function api(path, options={}) {
  const headers = Object.assign({}, options.headers || {});
  if (options.body && !headers['Content-Type']) headers['Content-Type']='application/json';
  if (csrfToken && options.method && options.method !== 'GET') headers['X-CSRF-Token']=csrfToken;
  const response = await fetch(path, Object.assign({}, options, {headers, credentials:'same-origin'}));
  if (response.status === 401) { location.href='/'; throw new Error('Session expired'); }
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || 'Request failed');
  return data;
}

async function loadSession() {
  const data = await api('/api/session');
  csrfToken = data.csrf_token;
  const pill = document.getElementById('env-pill');
  pill.textContent = data.environment === 'live' ? 'LIVE PAYSTACK' : 'TEST MODE';
  pill.classList.toggle('live', data.environment === 'live');
}
async function loadSummary() {
  const d = await api('/api/dashboard/summary');
  document.getElementById('today-revenue').textContent = naira(d.today_revenue);
  document.getElementById('total-revenue').textContent = naira(d.total_paid);
  document.getElementById('successful-count').textContent = Number(d.successful_count || 0).toLocaleString();
  document.getElementById('pending-count').textContent = Number(d.pending_count || 0).toLocaleString();
  document.getElementById('review-count').textContent = Number(d.review_count || 0).toLocaleString();
}
function statusClass(status) {
  if (status === 'PAID') return 'paid';
  if (status === 'REVIEW') return 'review';
  if (status === 'PENDING') return 'pending';
  return 'other';
}
async function loadPayments() {
  const q = document.getElementById('search').value.trim();
  const status = document.getElementById('status-filter').value;
  const params = new URLSearchParams({limit:'150'});
  if (q) params.set('q',q);
  if (status) params.set('status',status);
  const data = await api('/api/payments?' + params.toString());
  const body = document.getElementById('payments-body');
  if (!data.payments.length) {
    body.innerHTML = '<tr><td colspan="7" class="empty">No matching transactions found.</td></tr>';
  } else {
    body.innerHTML = data.payments.map(p => `<tr>
      <td><strong class="reference">${esc(p.payment_reference)}</strong><small>${esc(p.transaction_reference || 'Awaiting Paystack confirmation')}</small></td>
      <td><strong>${esc(p.patient_name || 'Paystack customer')}</strong><small>${esc(p.service_name || 'Payment received via Paystack')}</small></td>
      <td>${esc(p.department || '—')}</td>
      <td>${esc((p.payment_method || '—').replaceAll('_',' '))}</td>
      <td class="amount">${naira(p.amount_paid)}</td>
      <td><span class="status ${statusClass(p.payment_status)}">${esc(p.payment_status)}</span></td>
      <td>${esc(p.updated_at || '—')}</td></tr>`).join('');
  }
  document.getElementById('transaction-count').textContent = `${data.payments.length} transaction${data.payments.length===1?'':'s'} shown`;
  document.getElementById('last-updated').textContent = 'Updated ' + new Date().toLocaleTimeString();
  document.getElementById('feed-status').textContent = 'Connected';
  document.getElementById('feed-status').classList.add('connected');
  const currentIds = new Set(data.payments.map(p=>String(p.id)));
  if (lastPaymentIds.size && [...currentIds].some(id=>!lastPaymentIds.has(id))) {
    document.title = 'Payment update • IMSUTH PAYPOINT';
  }
  lastPaymentIds = currentIds;
}
async function loadDepartments() {
  const data = await api('/api/reports/departments');
  const body = document.getElementById('departments-body');
  if (!data.departments.length) {
    body.innerHTML = '<tr><td colspan="3" class="empty">No verified department revenue yet.</td></tr>';
    return;
  }
  body.innerHTML = data.departments.map(d => `<tr><td><strong>${esc(d.department)}</strong></td><td>${Number(d.transaction_count).toLocaleString()}</td><td class="amount">${naira(d.revenue)}</td></tr>`).join('');
}
async function refreshAll() {
  try {
    await Promise.all([loadSummary(), loadPayments(), loadDepartments()]);
  } catch (e) {
    document.getElementById('feed-status').textContent = 'Reconnecting';
    document.getElementById('feed-status').classList.remove('connected');
    console.error(e);
  }
}
document.getElementById('payment-form').addEventListener('submit', async e => {
  e.preventDefault();
  const form = e.currentTarget;
  const fd = new FormData(form);
  const payload = Object.fromEntries(fd.entries());
  const msg = document.getElementById('payment-message');
  const button = form.querySelector('button[type="submit"]');
  button.disabled = true; button.textContent = 'Connecting to Paystack…';
  msg.className='notice'; msg.textContent='Creating a secure payment session…';
  try {
    const result = await api('/api/payments/initiate', {method:'POST', body:JSON.stringify(payload)});
    msg.className='notice success';
    msg.textContent='Payment reference created: ' + result.payment_reference + '. Opening Paystack checkout…';
    window.open(result.checkout_url, '_blank', 'noopener');
    await refreshAll();
  } catch (err) {
    msg.className='notice error'; msg.textContent=err.message;
  } finally {
    button.disabled=false; button.textContent='Create checkout';
  }
});
document.getElementById('search').addEventListener('input', debounce(loadPayments, 250));
document.getElementById('status-filter').addEventListener('change', loadPayments);
document.getElementById('logout-btn').addEventListener('click', async () => {
  try { await api('/api/logout',{method:'POST',body:'{}'}); } finally { location.href='/'; }
});
function debounce(fn, delay) { let timer; return (...args)=>{clearTimeout(timer);timer=setTimeout(()=>fn(...args),delay);}; }
(async () => {
  try { await loadSession(); await refreshAll(); setInterval(refreshAll, 1500); }
  catch (e) { console.error(e); }
})();
