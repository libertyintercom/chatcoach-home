# IMSUTH PAYPOINT — Flask + MySQL + uWSGI + Paystack

Cashiers start a payment; patients pay on Paystack checkout (card, bank transfer, USSD, bank).
Paystack calls `POST /webhooks/paystack` when money arrives. The app checks the HMAC signature,
then re-verifies the transaction with Paystack's API before recording it, so the dashboard only shows
money Paystack confirms. Any successful charge on the Paystack account (including payments this app did
not create, such as dedicated virtual account transfers) is recorded too, as "Payment received via Paystack".

**Install on Ubuntu 24.04: follow `INSTALL_UBUNTU24.md`.**

## How it works
- `POST /api/payments/initiate` creates a PENDING row, calls Paystack `transaction/initialize` (amount in kobo) and returns the checkout URL.
- `POST /webhooks/paystack` verifies `x-paystack-signature` (HMAC-SHA512 of the raw body with the secret key), stores the event idempotently, calls `transaction/verify/:reference`, then marks PAID. A different amount than expected goes to REVIEW. Failed processing returns 500 so Paystack retries, and the retry is re-processed (not dropped as a duplicate).
- `reconcile.py` (systemd timer, every 5 min) re-verifies PENDING payments, covering any webhook that never arrived.
- Nginx only lets Paystack's published IPs reach the webhook URL (52.31.139.75, 52.49.173.169, 52.214.14.220), on top of the signature check.
- Test vs live is decided by the key prefix (`sk_test_` / `sk_live_`). `APP_ENV=production` refuses to start with a test key.

## Limits you should know
- Only money that goes through Paystack is visible. Cash, POS machines and direct deposits into a normal bank account are not reported by Paystack.
- The dashboard shows verified payments, not bank settlement.
- Login is still a single shared admin account. See `SECURITY_HARDENING.md`: add individual accounts, roles, throttling and MFA before staff use it with real data.

## Files
`app.py` app · `schema.sql` tables · `migrations/001_monnify_to_paystack.sql` (only for an existing Monnify-era database) · `reconcile.py` · `deployment/` nginx, systemd units, backup scripts · `.env.example`
